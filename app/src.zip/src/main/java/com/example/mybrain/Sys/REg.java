package com.example.mybrain.Sys;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mybrain.R;

public class REg extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.repass);

    }
}

