package com.example.mybrain.Sys;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mybrain.R;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CardManager extends AppCompatActivity {

    private TextView taskText;
    private Button btnBack, btnAnswer;
    private boolean showingAnswer = false;
    private List<HistoryEntry> history = new ArrayList<>();
    private int currentHistoryIndex = -1;
    private Random random = new Random();

    // Внутренний класс для хранения истории
    private static class HistoryEntry {
        int cardIndex;
        boolean showDefinitionAsQuestion;

        HistoryEntry(int cardIndex, boolean showDefinitionAsQuestion) {
            this.cardIndex = cardIndex;
            this.showDefinitionAsQuestion = showDefinitionAsQuestion;
        }
    }

    String[][] flashcards = {
            // Математика
            {"S = πr²", "Формула площади круга (r - радиус)"},
            {"V = (4/3)πr³", "Формула объёма шара"},
            {"sin²α + cos²α = 1", "Основное тригонометрическое тождество"},
            {"a³ - b³ = (a - b)(a² + ab + b²)", "Формула разности кубов"},
            {"ln(e) = 1", "Натуральный логарифм числа e"},
            {"∫a dx = ax + C", "Интеграл от константы"},

            // Физика
            {"F = G*(m₁m₂)/r²", "Закон всемирного тяготения"},
            {"P = ρgh", "Давление жидкости на глубине h"},
            {"Q = cmΔT", "Формула количества теплоты"},
            {"I = U/R", "Закон Ома для участка цепи"},
            {"λ = v/f", "Связь длины волны с частотой и скоростью"},
            {"A = qΔφ", "Работа электростатического поля"},

            // Химия
            {"pH = -lg[H+]", "Формула водородного показателя"},
            {"ν = V/V_m", "Количество газообразного вещества"},
            {"ω = (m_вещ/m_смеси)*100%", "Массовая доля вещества"},
            {"Al₂O₃ + 6HCl → 2AlCl₃ + 3H₂O", "Реакция оксида алюминия с соляной кислотой"},
            {"C₆H₁₂O₆ → 2C₂H₅OH + 2CO₂", "Спиртовое брожение глюкозы"},

            // Русский язык
            {"-ться/-тся", "Окончание глаголов определяется вопросом: что делать?/что делает?"},
            {"НЕ с глаголами", "Пишется раздельно, кроме исключений (негодовать, ненавидеть)"},
            {"Причастный оборот", "Выделяется запятыми, если стоит после определяемого слова"},
            {"Правописание Н/НН", "В суффиксах страдательных причастий прошедшего времени"},

            // Обществознание
            {"Инфляция", "Устойчивое повышение общего уровня цен"},
            {"Социальная стратификация", "Расслоение общества на группы по различным критериям"},
            {"Правовое государство", "Государство, ограниченное в своих действиях правом"},
            {"ВВП", "Рыночная стоимость всех конечных товаров и услуг"},

            // Биология
            {"Митохондрия", "Энергетическая станция клетки (синтез АТФ)"},
            {"Фотосинтез", "6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂"},
            {"Митоз", "Процесс деления соматических клеток"},
            {"Фенотип", "Совокупность внешних и внутренних признаков организма"},

            // Информатика
            {"IP-адрес", "Уникальный идентификатор устройства в сети"},
            {"HTTP 404", "Код состояния: страница не найдена"},
            {"Алгоритм Дейкстры", "Поиск кратчайшего пути в графе"},
            {"O(n log n)", "Сложность быстрой сортировки (QuickSort)"},

            // История
            {"862 г.", "Призвание варягов (начало династии Рюриковичей)"},
            {"988 г.", "Крещение Руси князем Владимиром"},
            {"1242 г.", "Ледовое побоище (Александр Невский)"},
            {"1861 г.", "Отмена крепостного права в России"},
            {"1917 г.", "Великая Октябрьская социалистическая революция"},

            // География
            {"Антропогенный ландшафт", "Ландшафт, изменённый хозяйственной деятельностью"},
            {"Ингрессия", "Проникновение морских вод в понижения рельефа суши"},
            {"Субтропический пояс", "Расположен между тропическим и умеренным поясами"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_dashboard);

        taskText = findViewById(R.id.TasksBoard);
        btnBack = findViewById(R.id.btnBack);
        btnAnswer = findViewById(R.id.AnswerCard);
        Button btnForward = findViewById(R.id.btnForward);

        // Инициализация первой карточки
        int firstCard = random.nextInt(flashcards.length);
        history.add(new HistoryEntry(firstCard, random.nextBoolean()));
        currentHistoryIndex = 0;
        updateUI();

        btnForward.setOnClickListener(v -> moveForward());
        btnBack.setOnClickListener(v -> moveBack());
        btnAnswer.setOnClickListener(v -> toggleAnswer());
    }

    private void updateUI() {
        HistoryEntry entry = history.get(currentHistoryIndex);
        String[] card = flashcards[entry.cardIndex];

        String question = entry.showDefinitionAsQuestion ? card[1] : card[0];
        String answer = entry.showDefinitionAsQuestion ? card[0] : card[1];

        taskText.setText(showingAnswer ? answer : question);
        btnBack.setEnabled(currentHistoryIndex > 0);
        btnAnswer.setText(showingAnswer ? "Скрыть ответ" : "Показать ответ");
    }

    private void moveForward() {
        // Генерация новой уникальной карточки
        int newCard;
        do {
            newCard = random.nextInt(flashcards.length);
        } while (newCard == history.get(currentHistoryIndex).cardIndex);

        // Очистка истории после текущего индекса
        while (history.size() > currentHistoryIndex + 1) {
            history.remove(history.size() - 1);
        }

        history.add(new HistoryEntry(newCard, random.nextBoolean()));
        currentHistoryIndex++;
        showingAnswer = false;
        updateUI();
    }

    private void moveBack() {
        if (currentHistoryIndex > 0) {
            currentHistoryIndex--;
            showingAnswer = false;
            updateUI();
        }
    }

    private void toggleAnswer() {
        showingAnswer = !showingAnswer;
        updateUI();
    }
}