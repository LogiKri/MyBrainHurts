package com.example.mybrain.Sys;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.mybrain.R;
import com.example.mybrain.ui.TaskManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MainPage extends Fragment {

    private MaterialButton btnChooseSubject, taskStartButton;
    private final String[] subjects = {
            "Английский язык", "Биология", "География",
            "Информатика и ИКТ", "Испанский язык", "История",
            "Китайский язык", "Литература", "Математика. Базовый уровень",
            "Математика. Профильный уровень", "Немецкий язык", "Обществознание",
            "Русский язык", "Физика", "Французский язык", "Химия", "Итоговое изложение"
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        // Инициализация элементов
        btnChooseSubject = root.findViewById(R.id.btnChooseSubject);
        taskStartButton = root.findViewById(R.id.taskStartButton);
        taskStartButton.setVisibility(View.GONE);

        // Обработчики кнопок
        setupButtonListeners();

        return root;
    }

    private void setupButtonListeners() {
        btnChooseSubject.setOnClickListener(v -> showSubjectDialog());

        taskStartButton.setOnClickListener(v -> {
            String subject = btnChooseSubject.getText().toString();
            if (!subject.equals("Выбрать предмет")) {
                startActivity(new Intent(getActivity(), TaskManager.class)
                        .putExtra("subject", subject));
            } else {
                Toast.makeText(getContext(), "Сначала выберите предмет!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showSubjectDialog() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Выберите предмет")
                .setItems(subjects, (dialog, which) -> {
                    btnChooseSubject.setText(subjects[which]);
                    taskStartButton.setVisibility(View.VISIBLE);
                })
                .setNegativeButton("Отмена", null)
                .show();
    }
}