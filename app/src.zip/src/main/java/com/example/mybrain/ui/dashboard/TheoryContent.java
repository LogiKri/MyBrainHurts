package com.example.mybrain.ui.dashboard;
import java.util.HashMap;
import java.util.Map;

public class TheoryContent {
    private static final Map<String, Map<String, String>> CONTENT = new HashMap<>();

    static {
        // Математика
        Map<String, String> math = new HashMap<>();
        math.put("Тригонометрия",
                "Основные формулы тригонометрии:\n\n" +
                        "• sin²α + cos²α = 1\n" +
                        "• sin(α±β) = sinα cosβ ± cosα sinβ\n" +
                        "• cos(α±β) = cosα cosβ ∓ sinα sinβ");

        math.put("Алгебра",
                "Основы алгебры:\n\n" +
                        "• Квадратное уравнение: ax² + bx + c = 0\n" +
                        "• Дискриминант: D = b² - 4ac");

        CONTENT.put("📐 Математика", math);

        // Русский язык
        Map<String, String> russian = new HashMap<>();
        russian.put("Орфография",
                "Правила орфографии:\n\n" +
                        "• ЖИ/ШИ пиши с буквой И\n" +
                        "• ЧА/ЩА пиши с буквой А");

        CONTENT.put("📖 Русский язык", russian);
    }

    public static String getTheory(String subject, String topic) {
        return CONTENT.getOrDefault(subject, new HashMap<>())
                .getOrDefault(topic, "Теория в разработке 🚀");
    }
}